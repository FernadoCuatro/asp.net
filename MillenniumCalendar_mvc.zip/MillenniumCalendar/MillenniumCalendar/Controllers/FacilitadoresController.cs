﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MillenniumCalendar.Controllers
{
    public class FacilitadoresController : Controller
    {
        // Contexto de datos
        MillenniumCalendarDataContext database = new MillenniumCalendarDataContext();

        public ActionResult Index()
        {
            // Listar todos los facilitadores
            var ListaFacilitadores = database.SP_mostrar_facilitador().ToList();

            return View(ListaFacilitadores);
        }

        // GET: Facilitadores/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Facilitadores/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection, facilitador facilitador_datos)
        {
            try
            {
                facilitador_datos.facilitador_inserta = Session["nombre_completo"].ToString();
                facilitador_datos.fecha_inserta = DateTime.Now;

                // Se guardan los datos
                database.SP_agregar_facilitador(facilitador_datos.nombre_facilitador, facilitador_datos.estudio, facilitador_datos.estado_facilitador, facilitador_datos.facilitador_inserta, facilitador_datos.fecha_inserta);

                // Actualiza los datos
                database.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Facilitadores/Edit/5
        public ActionResult Edit(int id)
        {
            var info_facilitador = database.SP_buscar_facilitador_id(id).Single();
            return View(info_facilitador);
        }

        // POST: Facilitadores/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection, facilitador facilitador_datos)
        {
            try
            {
                // TODO: Add update logic here
                facilitador_datos.facilitador_actualiza = Session["nombre_completo"].ToString();
                facilitador_datos.fecha_actualiza = DateTime.Now;

                database.SP_actualiza_facilitador(id, facilitador_datos.nombre_facilitador, facilitador_datos.estudio, facilitador_datos.estado_facilitador, facilitador_datos.facilitador_actualiza, facilitador_datos.fecha_actualiza);

                // Actualizamos la base de datos
                database.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Facilitadores/Delete/5
        public ActionResult Delete(int id)
        {
            var info_facilitador = database.SP_buscar_facilitador_id(id).Single();
            return View(info_facilitador);
        }

        // POST: Facilitadores/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                database.SP_eliminar_facilitador(id);
                database.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
