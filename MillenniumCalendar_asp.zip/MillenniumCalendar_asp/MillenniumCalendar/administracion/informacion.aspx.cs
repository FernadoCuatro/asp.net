﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MillenniumCalendar.administracion;

namespace MillenniumCalendar.administracion
{
    public partial class informacion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Validamos que el usuario este logueado, si no lo esta no puede acceder al sitio
            if (Session["userLogin"] != null)
            {
                // Llenamos el contron GridView con la informacion
		        dgvInformacionAdministrador.DataSource = historialAdministradores();
                dgvInformacionAdministrador.DataBind();
            }
            else
            {
                // Enviamos al usuario al login
                Response.Redirect("~/login.aspx");
            }
        }

        protected DataTable historialAdministradores()
        {
            try {
                // Consulta a evaluar por medio del procedimiento almacenado
                string mostrar = "SELECT * FROM VW_listar_administradores";
                // Ejecutamos el objeto con SqlCommand, enviando como argumentos la Consulta y la Conexion
                // La conexion es un metodo estatico, puede ser accedido sin objeto
		        SqlCommand VW_listar_administradores = new SqlCommand(mostrar, Conexion.Conectar());

                // Obtenemos la informacion dentro de la clase SqlDataAdapter
		        SqlDataAdapter da = new SqlDataAdapter(VW_listar_administradores);
		        DataTable dt = new DataTable();
                // Con la variable de tipo SqlDataAdapter le decimos al metodo Fill que recupere los datos
                // y que los almacene en la variable de tipo DataTable
		        da.Fill(dt);

                // Retornamos nuestra variable de tipo DataTable
                return dt;
            }catch(Exception) {
                // Creamos una DateTable
                DataTable dt = new DataTable();
                // Retornamos una DateTable vacia
                return dt;
            }

        }
    }
}