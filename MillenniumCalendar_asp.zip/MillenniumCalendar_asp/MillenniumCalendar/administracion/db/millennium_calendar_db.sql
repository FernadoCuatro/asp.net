CREATE DATABASE millennium_calendar_db
GO
 USE millennium_calendar_db
GO
 -- -------------------
 -- TABLA [1/5] = administrador
 -- -------------------
 CREATE TABLE administrador (
  id_administrador INT IDENTITY(1, 1) CONSTRAINT Pk_id_administrador PRIMARY KEY NOT NULL,
  nombre VARCHAR(30),
  apellido VARCHAR(30),
  correo VARCHAR(70),
  clave VARBINARY(100),
  estado_administrador CHAR(2),
  administrador_inserta VARCHAR(30),
  fecha_inserta DATETIME,
  administrador_actualiza VARCHAR(30),
  fecha_actualiza DATETIME
 );

GO
 -- -------------------
 -- TABLA [2/5] = administrador_actividad
 -- -------------------
 CREATE TABLE administrador_actividad (
  id_proceso INT IDENTITY(1, 1) CONSTRAINT Pk_id_proceso PRIMARY KEY NOT NULL,
  id_administrador INT NOT NULL,
  id_actividad INT NOT NULL,
  fecha_proceso DATE,
  proceso_inserta VARCHAR(30),
  fecha_inserta DATETIME,
  proceso_actualiza VARCHAR(30),
  fecha_actualiza DATETIME
 );

GO
 -- -------------------
 -- TABLA [3/5] = actividad
 -- -------------------
 CREATE TABLE actividad (
  id_actividad INT IDENTITY(1, 1) CONSTRAINT Pk_id_actividad PRIMARY KEY not null,
  id_categoria INT NOT NULL,
  id_facilitador INT NOT NULL,
  nombre_actividad VARCHAR(30),
  fecha_inicio DATE,
  fecha_final DATE,
  dias VARCHAR(30),
  horario VARCHAR(30),
  duracion VARCHAR(30),
  descripcion VARCHAR(300),
  img_actividad VARCHAR(100),
  estado_actividad CHAR(2),
  actividad_inserta VARCHAR(30),
  fecha_inserta DATETIME,
  actividad_actualiza VARCHAR(30),
  fecha_actualiza DATETIME
 );

GO
 -- -------------------
 -- TABLA [4/5] = categoria
 -- -------------------
 CREATE TABLE categoria (
  id_categoria INT IDENTITY(1, 1) CONSTRAINT Pk_id_categoria PRIMARY KEY not null,
  nombre_categoria VARCHAR(30),
  descripcion VARCHAR(300),
  img_categoria VARCHAR(100),
  estado_categoria CHAR(2),
  usuario_inserta VARCHAR(30),
  fecha_inserta DATETIME,
  usuario_actualiza VARCHAR(30),
  fecha_actualiza DATETIME
 );

GO
 -- -------------------
 -- TABLA [5/5] = facilitador
 -- -------------------
 CREATE TABLE facilitador (
  id_facilitador INT IDENTITY(1, 1) CONSTRAINT Pk_id_facilitador PRIMARY KEY not null,
  nombre_facilitador VARCHAR(30),
  estudio VARCHAR(300),
  img_facilitador VARCHAR(100),
  estado_facilitador CHAR(2),
  facilitador_inserta VARCHAR(30),
  fecha_inserta DATETIME,
  facilitador_actualiza VARCHAR(30),
  fecha_actualiza DATETIME
 );

GO
 -- -------------------
 -- [RELACION ENTRE TABLAS]
 -- -------------------
ALTER TABLE
 administrador_actividad
ADD
 CONSTRAINT Fk_administradoractividad FOREIGN KEY (id_administrador) REFERENCES administrador(id_administrador)
ALTER TABLE
 administrador_actividad
ADD
 CONSTRAINT Fk_actividad_administrador FOREIGN KEY (id_actividad) REFERENCES actividad (id_actividad)
ALTER TABLE
 actividad
ADD
 CONSTRAINT Fk_actividad_categoria FOREIGN KEY (id_categoria) REFERENCES categoria (id_categoria)
ALTER TABLE
 actividad
ADD
 CONSTRAINT Fk_actividad_facilitador FOREIGN KEY (id_facilitador) REFERENCES facilitador (id_facilitador)
GO

 -- [PROCEDIMIENTOS ALMACENADOS]
 -- [PA LOGIN]
 CREATE PROCEDURE SP_ValidarUsuario @usuario VARCHAR(25),
 @clave VARCHAR(25),
 @patron VARCHAR(25) AS BEGIN IF EXISTS (
  SELECT
   *
  FROM
   administrador
  WHERE
   correo = @usuario
   AND CONVERT(VARCHAR(25), DECRYPTBYPASSPHRASE(@patron, clave)) = @clave
 )
SELECT
 *
FROM
 administrador
WHERE
 correo = @usuario
 AND CONVERT(VARCHAR(25), DECRYPTBYPASSPHRASE(@patron, clave)) = @clave
 ELSE
SELECT
 -1 id_administrador
END 
-- EXECUTE SP_ValidarUsuario 'carlos@gmail.com', 'Hola123', 'c@l3nd4R-Ml^!';
GO

 -- [PA TABLA ADMINISTRADOR]
 -- [TABLA ADMINISTRADOR 1/5] CREATE
 CREATE PROCEDURE SP_ingresar_administrador @nombre VARCHAR(30),
 @apellido VARCHAR(30),
 @correo VARCHAR(70),
 @clave VARCHAR(100),
 @estado_administrador CHAR(2),
 @administrador_inserta VARCHAR(30),
 @fecha_inserta DATETIME,
 @patron VARCHAR(50) AS BEGIN BEGIN TRY BEGIN TRAN
INSERT INTO
 administrador(
  nombre,
  apellido,
  correo,
  clave,
  estado_administrador,
  administrador_inserta,
  fecha_inserta
 )
VALUES
(
  @nombre,
  @apellido,
  @correo,
  ENCRYPTBYPASSPHRASE(@patron, @clave),
  @estado_administrador,
  @administrador_inserta,
  GETDATE()
 ) COMMIT
SELECT
 'EL ADMINISTRADOR FUE AGREGADO CON EXITO' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END 
GO
EXECUTE SP_ingresar_administrador 'Carlos','Castellanos','carlos@mail.com','Hola123','A','Carlos Castellanos',null,'c@l3nd4R-Ml^!' 
GO
 -- [TABLA ADMINISTRADOR 2/5] UPDATE
 CREATE PROCEDURE SP_actualizar_administrador @id_administrador INT,
 @nombre VARCHAR(30),
 @apellido VARCHAR(30),
 @correo VARCHAR(70),
 @clave VARCHAR(100),
 @estado_administrador CHAR(2),
 @usuario_inserta VARCHAR(30),
 @administrador_actualiza VARCHAR(30),
 @fecha_actualiza DATETIME,
 @patron VARCHAR(50) AS BEGIN BEGIN TRY BEGIN TRAN
UPDATE
 administrador
SET
 nombre = @nombre,
 apellido = @apellido,
 correo = @correo,
 clave = ENCRYPTBYPASSPHRASE(@patron, @clave),
 estado_administrador = @estado_administrador,
 administrador_actualiza = @administrador_actualiza,
 fecha_actualiza = GETDATE()
WHERE
 id_administrador = @id_administrador COMMIT
SELECT
 'EL ADMINISTRADOR FUE ACTUALIZADO CON EXITO' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END -- EXECUTE SP_actualizar_administrador 1,'Carlos','Vasquez','carlosgamil.com','123','A','Carlos','Alex','','c@l3nd4R-Ml^!'
GO
 -- [TABLA ADMINISTRADOR 3/5] READ 
 CREATE PROCEDURE SP_mostrar_administradores AS BEGIN BEGIN TRY BEGIN TRAN
SELECT
 id_administrador,
 nombre,
 apellido,
 correo,
 estado_administrador
FROM
 administrador
WHERE
 estado_administrador = 'A';

COMMIT
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END -- EXECUTE SP_mostrar_administradores
GO
 -- [TABLA ADMINISTRADOR 4/5] READ BY ID 
 CREATE PROCEDURE SP_buscar_administrador @id_administrador INT AS BEGIN BEGIN TRY BEGIN TRAN
SELECT
 *
FROM
 administrador
WHERE
 id_administrador = @id_administrador
 AND estado_administrador = 'A' COMMIT
SELECT
 'EL ADMINISTRADOR SE ENCONTRO' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA ADMINISTRADOR 5/5] DELETE 
 CREATE PROCEDURE SP_eliminar_administrador @id_administrador INT AS BEGIN BEGIN TRY BEGIN TRAN
UPDATE
 administrador
SET
 estado_administrador = 'I'
WHERE
 id_administrador = @id_administrador COMMIT
SELECT
 'EL ADMINISTRADOR SE A ELIMINADO' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END 
GO

-- [PA TABLA ADMINISTRADOR_ACTIVIDAD]
-- [TABLA ADMINISTRADOR_ACTIVIDAD 1/5] CREATE 
CREATE PROCEDURE SP_ingresar_administrador_actividad 
@id_administrador INT,
@id_actividad INT,
@fecha_proceso DATE,
@proceso_inserta VARCHAR(30),
@fecha_inserta DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
INSERT INTO
 administrador_actividad (
  id_administrador,
  id_actividad,
  fecha_proceso,
  proceso_inserta,
  fecha_inserta
 )
VALUES
 (
  @id_administrador,
  @id_actividad,
  @fecha_proceso,
  @proceso_inserta,
  GETDATE()
 ) COMMIT
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA ADMINISTRADOR_ACTIVIDAD 2/5] UPDATE 
 CREATE PROCEDURE SP_actualizar_administrador_actividad @id_proceso INT,
 @id_administrador INT,
 @id_actividad INT,
 @fecha_proceso DATE,
 @proceso_inserta VARCHAR(30),
 @proceso_actualiza VARCHAR(30),
 @fecha_actualiza DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
UPDATE
 administrador_actividad
SET
 id_administrador = @id_administrador,
 id_actividad = @id_actividad,
 fecha_proceso = @fecha_proceso,
 proceso_inserta = @proceso_inserta,
 proceso_actualiza = @proceso_actualiza,
 fecha_actualiza = GETDATE()
WHERE
 id_proceso = @id_proceso COMMIT
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA ADMINISTRADOR_ACTIVIDAD 3/5] READ 
 CREATE PROCEDURE SP_mostrar_administrador_actividad AS BEGIN BEGIN TRY BEGIN TRAN
SELECT
 id_proceso,
 id_administrador,
 id_actividad,
 fecha_proceso
FROM
 administrador_actividad COMMIT
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA ADMINISTRADOR_ACTIVIDAD 4/5] READ BY ID
 CREATE PROCEDURE SP_buscar_administrador_actividad @id_proceso INT AS BEGIN BEGIN TRY BEGIN TRAN
SELECT
 *
FROM
 administrador_actividad
WHERE
 id_proceso = @id_proceso COMMIT
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA ADMINISTRADOR_ACTIVIDAD 5/5] DELETE
 -- GO

 -- [PA TABLA ACTIVIDAD]
 -- [TABLA ACTIVIDAD 1/5] CREATE 
 CREATE PROCEDURE SP_ingresar_actividad @id_categoria INT,
 @id_facilitador INT,
 @nombre_actividad VARCHAR(30),
 @fecha_inicio DATE,
 @fecha_final DATE,
 @dias VARCHAR(30),
 @horario VARCHAR(30),
 @duracion VARCHAR(30),
 @descripcion VARCHAR(300),
 @img_actividad VARCHAR(100),
 @estado_actividad CHAR(2),
 @actividad_inserta VARCHAR(30),
 @fecha_inserta DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
INSERT INTO
 actividad (
  id_categoria,
  id_facilitador,
  nombre_actividad,
  fecha_inicio,
  fecha_final,
  dias,
  horario,
  duracion,
  descripcion,
  img_actividad,
  estado_actividad,
  actividad_inserta,
  fecha_inserta
 )
VALUES
 (
  @id_categoria,
  @id_facilitador,
  @nombre_actividad,
  @fecha_inicio,
  @fecha_final,
  @dias,
  @horario,
  @duracion,
  @descripcion,
  @img_actividad,
  @estado_actividad,
  @actividad_inserta,
  GETDATE()
 ) COMMIT
SELECT
 'LA ACTIVIDAD SE AGREGO CORRECTAMENTE' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA ACTIVIDAD 2/5] UPDATE 
 CREATE PROCEDURE SP_actualizar_actividad @id_actividad INT,
 @id_categoria INT,
 @id_facilitador INT,
 @nombre_actividad VARCHAR(30),
 @fecha_inicio DATE,
 @fecha_final DATE,
 @dias VARCHAR(30),
 @horario VARCHAR(30),
 @duracion VARCHAR(30),
 @descripcion VARCHAR(300),
 @img_actividad VARCHAR(100),
 @estado_actividad CHAR(2),
 @actividad_actualiza VARCHAR(30),
 @fecha_actualiza DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
UPDATE
 actividad
SET
 id_categoria = @id_categoria,
 id_facilitador = @id_facilitador,
 nombre_actividad = @nombre_actividad,
 fecha_inicio = @fecha_inicio,
 fecha_final = @fecha_final,
 dias = @dias,
 horario = @horario,
 duracion = @duracion,
 descripcion = @descripcion,
 img_actividad = @img_actividad,
 estado_actividad = @estado_actividad,
 actividad_actualiza = @actividad_actualiza,
 fecha_actualiza = @fecha_actualiza
WHERE
 id_actividad = @id_actividad COMMIT
SELECT
 'LA ACTIVIDAD FUE ACTUALIZADA CON EXITO' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA ACTIVIDAD 3/5] READ 
 CREATE PROCEDURE SP_mostrar_actividad AS BEGIN BEGIN TRY BEGIN TRAN
SELECT
 *
FROM
 actividad
WHERE
 estado_actividad = 'A' COMMIT
SELECT
 'LA ACTIVIDAD SE ENCONTRO' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA ACTIVIDAD 4/5] READ BY ID
 CREATE PROCEDURE SP_buscar_actividad @id_actividad INT AS BEGIN BEGIN TRY BEGIN TRAN
SELECT
 *
FROM
 actividad
WHERE
 id_actividad = @id_actividad
 AND estado_actividad = 'A' COMMIT
SELECT
 'LA ACTIVIDAD SE ENCONTRO' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA ACTIVIDAD 5/5] DELETE
 CREATE PROCEDURE SP_eliminar_actividad @id_actividad INT AS BEGIN BEGIN TRY BEGIN TRAN
UPDATE
 actividad
SET
 estado_actividad = 'I'
WHERE
 id_actividad = @id_actividad COMMIT
SELECT
 'LOS DATOS HAN SIDO ELIMINADOS' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'A OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END 
GO

-- [PA TABLA ACTIVIDAD]
-- [TABLA ACTIVIDAD 1/5] CREATE 
CREATE PROCEDURE SP_agregar_categoria @id_categoria INT,
@nombre_categoria VARCHAR(30),
@descripcion VARCHAR(300),
@img_categoria VARCHAR(100),
@estado_categoria CHAR(2),
@usuario_inserta VARCHAR(30),
@fecha_inserta DATETIME,
@usuario_actualiza VARCHAR(30),
@fecha_actualiza DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
INSERT INTO
 categoria
VALUES
(
  @nombre_categoria,
  @descripcion,
  @img_categoria,
  @estado_categoria,
  @usuario_inserta,
  @fecha_inserta,
  @usuario_actualiza,
  @fecha_actualiza
 ) COMMIT
SELECT
 'LA CATEGORIA FUE AGREGADA CON EXITO' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA ACTIVIDAD 2/5] UPDATE 
 CREATE PROCEDURE SP_actualiza_categoria @id_categoria INT,
 @nombre_categoria VARCHAR(30),
 @descripcion VARCHAR(300),
 @img_categoria VARCHAR(100),
 @estado_categoria CHAR(2),
 @usuario_inserta VARCHAR(30),
 @fecha_inserta DATETIME,
 @usuario_actualiza VARCHAR(30),
 @fecha_actualiza DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
UPDATE
 categoria
SET
 nombre_categoria = @nombre_categoria,
 descripcion = @descripcion,
 img_categoria = @img_categoria,
 estado_categoria = @estado_categoria,
 usuario_inserta = @usuario_inserta,
 fecha_inserta = @fecha_inserta,
 usuario_actualiza = @usuario_actualiza,
 fecha_actualiza = @fecha_actualiza
WHERE
 id_categoria = @id_categoria COMMIT
SELECT
 'LA CATEGORIA FUE ACTUALIZADA CON EXITO' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA ACTIVIDAD 3/5] READ 
 CREATE VIEW VW_buscar_categoria_Estado AS
SELECT
 id_categoria,
 nombre_categoria,
 descripcion,
 img_categoria,
 estado_categoria
FROM
 categoria
WHERE
 estado_categoria = 'A'
GO
 -- [TABLA ACTIVIDAD 4/5] READ BY ID
 CREATE PROCEDURE SP_buscar_categoria_ID @id_categoria INT AS BEGIN BEGIN TRY BEGIN TRAN
SELECT
 id_categoria,
 nombre_categoria,
 descripcion,
 img_categoria,
 estado_categoria
FROM
 categoria
WHERE
 id_categoria = @id_categoria COMMIT
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA ACTIVIDAD 5/5] DELETE
 CREATE PROCEDURE SP_eliminar_categoria @id_categoria INT AS BEGIN BEGIN TRY BEGIN TRAN
UPDATE
 categoria
SET
 estado_categoria = 'I'
WHERE
 id_categoria = @id_categoria COMMIT
SELECT
 'LA CATEGORIA SE INHABILITO' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO

 -- [PA TABLA FACILITADOR]
 -- [TABLA FACILITADOR 1/5] CREATE
 CREATE PROCEDURE SP_agregar_facilitador @id_facilitador INT,
 @nombre_facilitador VARCHAR(30),
 @estudio VARCHAR(300),
 @img_facilitador VARCHAR(100),
 @estado_facilitador CHAR(2),
 @facilitador_inserta VARCHAR(30),
 @fecha_inserta DATETIME,
 @facilitador_actualiza VARCHAR(30),
 @fecha_actualiza DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
INSERT INTO
 facilitador
VALUES
(
  @nombre_facilitador,
  @estudio,
  @img_facilitador,
  @estado_facilitador,
  @facilitador_inserta,
  @fecha_inserta,
  @facilitador_actualiza,
  @fecha_actualiza
 ) COMMIT
SELECT
 'EL FACILITADOR FUE AGREGADO CON EXITO' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA FACILITADOR 2/5] UPDATE
 CREATE PROCEDURE SP_actualiza_facilitador @id_facilitador INT,
 @nombre_facilitador VARCHAR(30),
 @estudio VARCHAR(300),
 @img_facilitador VARCHAR(100),
 @estado_facilitador CHAR(2),
 @facilitador_inserta VARCHAR(30),
 @fecha_inserta DATETIME,
 @facilitador_actualiza VARCHAR(30),
 @fecha_actualiza DATETIME AS BEGIN BEGIN TRY BEGIN TRAN
UPDATE
 facilitador
SET
 nombre_facilitador = @nombre_facilitador,
 estudio = @estudio,
 img_facilitador = @img_facilitador,
 estado_facilitador = @estado_facilitador,
 facilitador_inserta = @facilitador_inserta,
 fecha_inserta = @fecha_inserta,
 facilitador_actualiza = @facilitador_actualiza,
 fecha_actualiza = @fecha_actualiza
WHERE
 id_facilitador = @id_facilitador COMMIT
SELECT
 'EL FACILITADOR FUE ACTUALIZADO CON EXITO' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA FACILITADOR 3/5] READ
 CREATE PROCEDURE SP_mostrar_facilitador AS BEGIN BEGIN TRY BEGIN TRAN
SELECT
 *
FROM
 facilitador
WHERE
 estado_facilitador = 'A' COMMIT
SELECT
 'SE HA ENCONTRADO AL FACILITADOR' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA FACILITADOR 4/5] READ BY ID
 CREATE PROCEDURE SP_buscar_facilitador_id @id_facilitador INT AS BEGIN BEGIN TRY BEGIN TRAN
SELECT
 *
FROM
 facilitador
WHERE
 id_facilitador = @id_facilitador COMMIT
SELECT
 'SE HA ENCONTRADO AL FACILITADOR' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO
 -- [TABLA FACILITADOR 5/5] DELETE
 CREATE PROCEDURE SP_eliminar_facilitador @id_facilitador INT AS BEGIN BEGIN TRY BEGIN TRAN
UPDATE
 facilitador
SET
 estado_facilitador = 'I'
WHERE
 id_facilitador = @id_facilitador COMMIT
SELECT
 'EL FACILITADOR SE ELIMINO' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'HA OCURRIDO UN ERROR' + ERROR_MESSAGE() Mensaje
END CATCH
END

CREATE VIEW VW_listar_administradores AS
  SELECT nombre,apellido,correo,estado_administrador,administrador_inserta,fecha_inserta,administrador_actualiza,fecha_actualiza 
FROM administrador

------------------------------------------------
------------------------------------------------
-- TOTAL TABLAS: 5 
-- TOTAL DE PROCEDIMIENTOS ALMACENADOS: 24 
-- TOTAL DE VISTAS: 2
------------------------------------------------
------------------------------------------------