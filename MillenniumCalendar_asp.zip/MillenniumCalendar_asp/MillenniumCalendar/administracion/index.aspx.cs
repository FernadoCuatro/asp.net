﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MillenniumCalendar.administracion
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Validamos que el usuario este logueado, si no lo esta no puede acceder al sitio
            if (Session["userLogin"] != null)
            {
                // Mostramos un mensaje de bienvenida
                lblBienvenida.Text = $"¡Hola {Session["nombre"].ToString()}!";
            }
            else
            {
                // Enviamos al usuario al login
                Response.Redirect("~/login.aspx");
            }
        }
    }
}