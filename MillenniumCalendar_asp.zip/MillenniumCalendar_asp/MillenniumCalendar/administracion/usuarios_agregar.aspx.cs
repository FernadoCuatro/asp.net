﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MillenniumCalendar.administracion;

namespace MillenniumCalendar.administracion.accion
{
    public partial class usuarios_agregar : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Si la seccion no existe, no se puede acceder al sitio
            if (!(Session["userLogin"] != null))
            {
                Response.Redirect("~/login.aspx");
            }
        }

        protected void btnCrear_Click(object sender, EventArgs e)
        {
            // Confirmamos que las contraseñas coicidan
            if(txtPw.Text.Equals(txtConfirmacion.Text)) {

                try
                {
                // Consulta a evaluar por medio del procedimiento almacenado
                string insertarUsuario = "EXECUTE SP_ingresar_administrador @nombre,@apellido,@correo,@pw,@estado,@inserta, null ,@patron; ";
                // Ejecutamos el objeto con SqlCommand, enviando como argumentos la Consulta y la Conexion
                // La conexion es un metodo estatico, puede ser accedido sin objeto
                SqlCommand SP_ingresar_administrador = new SqlCommand(insertarUsuario, Conexion.Conectar());
                // Definimos los argumentos a los parametros de la consulta al objeto de SqlCommand
                SP_ingresar_administrador.Parameters.AddWithValue("@nombre", txtNombre.Text);
                SP_ingresar_administrador.Parameters.AddWithValue("@apellido", txtApellido.Text);
                SP_ingresar_administrador.Parameters.AddWithValue("@correo", txtCorreo.Text);
                SP_ingresar_administrador.Parameters.AddWithValue("@pw", txtPw.Text);
                SP_ingresar_administrador.Parameters.AddWithValue("@estado", "A");
                SP_ingresar_administrador.Parameters.AddWithValue("@inserta", Session["nombre"].ToString() + " " + Session["apellido"].ToString());
                SP_ingresar_administrador.Parameters.AddWithValue("@patron", "c@l3nd4R-Ml^!");
                // Con este metodo podemos pasar instrucciones DML
                // (UPDATE, INSERT O DELETE) esto retorna un int
                SP_ingresar_administrador.ExecuteNonQuery();

                // Redirigimos a la pagina de usuarios
                Response.Redirect("usuarios.aspx");
                }
                catch (Exception)
                {
                    // Manejamos algun error
                    lblAlerta.Text = "Imposible procesar la información en este momento";
                }


            } else {
                lblAlerta.Text = "Contraseña no coicide";
            }
        }
    }
}