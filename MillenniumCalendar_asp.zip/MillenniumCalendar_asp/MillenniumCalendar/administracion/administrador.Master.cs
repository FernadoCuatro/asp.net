﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MillenniumCalendar.administracion
{
    public partial class Administrador : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
             // Validamos que el usuario este logueado, si no lo esta no puede acceder al sitio
            if (Session["userLogin"] != null)
            {   
                // Le establecemos el correo al label de la parte superior
                lblCorreoUsuario.Text = Session["correo"].ToString();
            }
            else
            {
                // Enviamos al usuario al login
                Response.Redirect("~/login.aspx");
            }
        }

        protected void btnCerrar_Click(object sender, EventArgs e)
        {
            // Removemos todas las sessiones al cerrar
            Session.Remove("userLogin");
            Session.Remove("id");
            Session.Remove("nombre");
            Session.Remove("apellido");
            Session.Remove("correo");

            // Enviamos al usuario al login
            Response.Redirect("~/login.aspx");
        }
    }
}