﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// Siempre cuando utilicemos comandos SQL
// llamaremos a la coleccion de SqlClient
using System.Data.SqlClient;

namespace MillenniumCalendar
{
 // Creamos la clase correspondiente
 class Conexion
 {
  // Creamos un metodo estatico para abrir la conexion y 
  // retornar la conexion de tipo SqlConnection
  public static SqlConnection Conectar()
  {
   // -- SERVER   >> El nombre del servidor de SQLServer 
   // -- DATABASE >> Base de datos a utilizar
   // -- Integrated Security=true >> Para iniciar con la autenticación de windows 
   //                                y no procesar la User ID y la Password de SQLServer
   SqlConnection conn = new SqlConnection("SERVER=LATITUDE-E6510; DATABASE=millennium_calendar_db; Integrated Security=true;");
   conn.Open();
   return conn;
  }
 }
}
