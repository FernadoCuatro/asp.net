﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using MillenniumCalendar.administracion;

namespace MillenniumCalendar
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
            // Consulta a evaluar por medio del procedimiento almacenado
            string iniciarAdmim = "EXECUTE SP_ValidarUsuario @usuario, @clave, @patron"; 
            // Ejecutamos el objeto con SqlCommand, enviando como argumentos la Consulta y la Conexion
            // La conexion es un metodo estatico, puede ser accedido sin objeto
            SqlCommand SP_ValidarUsuario = new SqlCommand(iniciarAdmim, Conexion.Conectar());
            
            // Definimos los argumentos a los parametros de la consulta al objeto de SqlCommand
            SP_ValidarUsuario.Parameters.AddWithValue("@usuario", txtCorreo.Text);
            SP_ValidarUsuario.Parameters.AddWithValue("@clave", txtPw.Text);
            SP_ValidarUsuario.Parameters.AddWithValue("@patron", "c@l3nd4R-Ml^!");

            // Con este metodo podemos pasar instrucciones DML
            // (UPDATE, INSERT O DELETE) esto retorna un int
            SqlDataAdapter sda = new SqlDataAdapter(SP_ValidarUsuario);

            // Creamos un DataTable para tener almacenar las columnas y las filas de datos
            DataTable dt = new DataTable();
             // Con la variable de tipo SqlDataAdapter le decimos al metodo Fill que recupere los datos
             // y que los almacene en la variable de tipo DataTable
            sda.Fill(dt);

                // Evaluamos que en la DataTable exista una fila mayor que -1, para corroborar que exista el usuario
                if(Convert.ToInt32(dt.Rows[0][0].ToString()) > 0)
                {
                // inicializamos las variables estaticas con la informacion establecida en la DataTable
                Session["userLogin"] = "valido";
                Session["id"] = Convert.ToInt32(dt.Rows[0][0].ToString());
                Session["nombre"] = dt.Rows[0][1].ToString();
                Session["apellido"] = dt.Rows[0][2].ToString();
                Session["correo"] = dt.Rows[0][3].ToString();

                // Rediriguimos a la siguiente pagina
                Response.Redirect("administracion/index.aspx");
                }
                else
                {
                    // Alerta al usuario por el error
                    lblErrorUsuario.Visible = true;
                }
            }
            catch (Exception)
            {
                    // Alerta al usuario por el error
                    lblErrorUsuario.Visible = true;
            }

        }
    }
}