﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
// Siempre cuando utilicemos comandos SQL
// llamaremos a la coleccion de SqlClient
using System.Data.SqlClient;

namespace Parcial2_2508712020
{
 // Creamos la clase correspondiente
 class Conexion
 {
    // Abrimos la conexion por medio de un metodo estatico que devuelve un tipo de dato SqlConnection
    public static SqlConnection Conectar()
    {
        SqlConnection conn = new SqlConnection("SERVER=LATITUDE-E6510; DATABASE=parcial2_2508712020_db; Integrated Security=true;");
        conn.Open();
        return conn;
    }
   
    // Cerrarmos la conexion por medio de un metodo estatico con void
    public static void Cerrar()
    {
       Conectar().Close();
    }
 }
}
