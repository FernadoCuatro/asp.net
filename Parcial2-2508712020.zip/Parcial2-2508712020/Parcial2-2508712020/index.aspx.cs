﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

namespace Parcial2_2508712020
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        // Llenamos el contron GridView con la informacion
		dgvPersonas.DataSource = refrescarPersonas();
        dgvPersonas.DataBind();
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            try
            {
                // Consulta a evaluar por medio del procedimiento almacenado
                string insertarPersona = "EXEC SP_insertar_persona @nombre, @apellido, @edad;";

                // La conexion es un metodo estatico, puede ser accedido sin objeto
                SqlCommand SP_insertar_persona = new SqlCommand(insertarPersona, Conexion.Conectar());

                // Definimos los argumentos a los parametros de la consulta al objeto de SqlCommand
                SP_insertar_persona.Parameters.AddWithValue("@nombre", Convert.ToString(txtNombre.Text));
                SP_insertar_persona.Parameters.AddWithValue("@apellido", Convert.ToString(txtApellido.Text));
                SP_insertar_persona.Parameters.AddWithValue("@edad", Convert.ToInt32(txtEdad.Text));

                // Con este metodo podemos pasar instrucciones DML
                // (UPDATE, INSERT O DELETE) esto retorna un int
                SP_insertar_persona.ExecuteNonQuery();

                // Cerramos la conexión
                Conexion.Cerrar();

                // Limpiamos los controles despues del envio
                limpiarFormulario();

                // Llenamos el contron GridView con la informacion
		        dgvPersonas.DataSource = refrescarPersonas();
                dgvPersonas.DataBind();
            }
            catch (Exception ex)
            {
                lblAlerta.Text = "Ocurrio un error. +info: " + ex.Message;
            }
        }

        protected DataTable refrescarPersonas()
        {
            try {
                // Consulta a evaluar por medio del procedimiento almacenado
                string mostrar = "SELECT * FROM VW_ver_personas;";
                // Ejecutamos el objeto con SqlCommand, enviando como argumentos la Consulta y la Conexion
                // La conexion es un metodo estatico, puede ser accedido sin objeto
		        SqlCommand VW_ver_personas = new SqlCommand(mostrar, Conexion.Conectar());

                // Obtenemos la informacion dentro de la clase SqlDataAdapter
		        SqlDataAdapter da = new SqlDataAdapter(VW_ver_personas);
		        DataTable dt = new DataTable();
                // Con la variable de tipo SqlDataAdapter le decimos al metodo Fill que recupere los datos
                // y que los almacene en la variable de tipo DataTable
		        da.Fill(dt);

                // Cerramos la conexión
                Conexion.Cerrar();

                // Retornamos nuestra variable de tipo DataTable
                return dt;
            }catch(Exception) {
                // Creamos una DateTable
                DataTable dt = new DataTable();
                // Retornamos una DateTable vacia
                return dt;
            }
        }

        protected void limpiarFormulario()
        {
            txtNombre.Text = "";
            txtApellido.Text = "";
            txtEdad.Text = "";
        }

    }
}