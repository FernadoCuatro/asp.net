CREATE DATABASE parcial2_2508712020_db;
GO
USE parcial2_2508712020_db;
GO

-- [1/1] Tabla persona
create table persona (
id_persona INT IDENTITY(1, 1) CONSTRAINT Pk_id_persona PRIMARY KEY NOT NULL,
nombre VARCHAR(50),
apellido VARCHAR(50),
edad TINYINT
)
GO

-- Stored Procedures
-- Create 
 CREATE PROCEDURE SP_insertar_persona 
 @nombre VARCHAR(50),
 @apellido VARCHAR(50),
 @edad TINYINT
 AS BEGIN BEGIN TRY BEGIN TRAN
	INSERT INTO persona(nombre, apellido, edad)
	VALUES(@nombre, @apellido, @edad) 
COMMIT
SELECT
 'Se agrego la informaci�n de la persona' Mensaje
END TRY BEGIN CATCH IF @@TRANCOUNT > 0 ROLLBACK
SELECT
 'Ocurrio un error | +info: ' + ERROR_MESSAGE() Mensaje
END CATCH
END
GO

-- Read
CREATE VIEW VW_ver_personas AS
  SELECT nombre, apellido, edad FROM persona
GO
