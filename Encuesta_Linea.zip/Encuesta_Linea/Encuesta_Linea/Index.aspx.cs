﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Encuesta_Linea
{
    public partial class Index : System.Web.UI.Page
    {
        int contador;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                contador = 0;
            }
           
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            string Nombre = txtNombre.Text;
            int edad = Convert.ToInt32(txtEdad.Text);
            int valorProfesional = Convert.ToInt32(ddlProfesion.SelectedValue.ToString());

            bool Trabaja = cbxTrabaja.Checked;

            contador = int.Parse(lblCantidad.Text) + 1;

            lblCantidad.Text = contador.ToString();

        }
    }
}