-- Creamos la base de datos
create database SeminarioWebServiceIIS
GO
-- Utilizamos la base de datos ya creada
use SeminarioWebServiceIIS
GO

-- Creamos la tabla usuarios
create table usuarios (
id_usuario INT PRIMARY KEY IDENTITY(1,1),
nombre VARCHAR(50),
login VARCHAR(25),
password VARBINARY(500),
estado BIT,
email VARCHAR(50),
id_privilegio INT,
fecha DATE DEFAULT GETDATE()
);
GO

-- Creamos la tabla provilegios
create table provilegios (
id_privilegio INT PRIMARY KEY IDENTITY(1,1),
nombre_privilegio VARCHAR(25) 
);
GO

-- Relacionamos la tablas para la FOREIGN KEY
ALTER TABLE usuarios ADD CONSTRAINT FK_usuarios_provilegios FOREIGN KEY (id_privilegio) REFERENCES provilegios(id_privilegio);
GO 

-- Insertamos los provilegios de forma manual
insert into provilegios values('usuario');
insert into provilegios values('supervisor');
insert into provilegios values('jefe');
insert into provilegios values('gerente');
insert into provilegios values('directivo');
insert into provilegios values('administrador');

GO 
-- Creamos el Stored procedure para crear usuarios 
create procedure SP_crear_usuario
@nombre VARCHAR(50),
@login VARCHAR(25),
@password VARCHAR(500),
@patron VARCHAR(25),
@estado BIT,
@email VARCHAR(50),
@id_privilegio INT
AS
BEGIN
insert into usuarios values(@nombre, @login, ENCRYPTBYPASSPHRASE(@patron, @password), @estado, @email, @id_privilegio, GETDATE());
END

GO 
-- Creamos el Stored Procedure para validar los usuarios
Create Procedure SP_validar_usuario
@Login varchar(25),
@Password varchar(25),
@Patron varchar(25)
As
Begin
If Exists (Select * From usuarios Where login=@Login
And Convert(varchar(25),DecryptByPassPhrase(@Patron,password))=@Password)
Select * From usuarios Where login=@Login
And Convert(varchar(25),DecryptByPassPhrase(@Patron,password))=@Password
Else
Select -1 id_usuario --Cuando tenga -1 indica que el usuario no existe
End

-- EXECUTE SP_crear_usuario 'Fernando', 'KV', '123', 'S3m1n@r10', 1, 'fernando@seminario.com', 6;
-- Exec SP_validar_usuario 'KV','123','S3m1n@r10'

select * from usuarios;
select * from provilegios;