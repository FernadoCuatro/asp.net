﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class login : System.Web.UI.Page
{
    // Referencia al servicio web
    wcfDatos.ServiceClient ws = new wcfDatos.ServiceClient();

    // Repositorio de datos
    DataSet ds = new DataSet();
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnIngresar_Click(object sender, EventArgs e)
    {
        try
        {
            ds = ws.ValidarUsuario(txtLogin.Text, txtClave.Text);

            if (ds != null)
            {
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables["usuarios"].Rows.Count > 0)
                    {
                        if(ds.Tables["usuarios"].Rows[0]["id_usuario"].ToString() != "1-")
                        {
                            lblMensajes.Text = "Bienvenido al sistema, " + ds.Tables["usuarios"].Rows[0]["nombre"].ToString() + "!";
                        }else {
                            lblMensajes.Text = "Usuario no encontrado";
                        }
                    }
                    else {
                        lblMensajes.Text = "Sin registro";
                    }
                }
                else {
                    lblMensajes.Text = "Sin Tablas";
                }
            }else {
                lblMensajes.Text = "Error en el proceso";
            }
        }
        catch (Exception ex)
        {
            lblMensajes.Text = "Error | +info: " + ex.Message;
        }

    }
}