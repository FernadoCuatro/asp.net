﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Data;
using System.Data.SqlClient;

// NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Service1" en el código, en svc y en el archivo de configuración.
public class Service : IService
{
    DataSet ds = new DataSet(); // Repositorio de datos en memoria
    SqlDataAdapter da; // Para ejecutar los PA en la DB
    string patron = "S3m1n@r10";

    string strConexion = @"Data Source=LATITUDE-E6510; Initial Catalog=SeminarioWebServiceIIS; User='seminario_user'; Password='123'";
    

	public DataSet ValidarUsuario(string login, string pw)
	{
        da = new SqlDataAdapter("SP_validar_usuario", strConexion);
        da.SelectCommand.CommandType = CommandType.StoredProcedure;
        da.SelectCommand.Parameters.AddWithValue("@Login", login);
        da.SelectCommand.Parameters.AddWithValue("@Password", pw);
        da.SelectCommand.Parameters.AddWithValue("@Patron", patron);

        da.Fill(ds, "Usuario");

		return ds;
	}


}
