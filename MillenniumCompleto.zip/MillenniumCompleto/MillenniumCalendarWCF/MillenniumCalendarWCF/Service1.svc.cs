﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace MillenniumCalendarWCF
{
    public class Service1 : IService1
    {
        // Contexto de datos
        MillenniumCalendarDataContext database = new MillenniumCalendarDataContext();

        public List<VW_listar_actividades> VW_listar_actividades()
        {
            var ListaActividades = (from c in database.VW_listar_actividades select c).ToList();
            return ListaActividades;
        }

        public List<VW_listar_categorias> VW_listar_categorias()
        {
            var ListaCategorias = (from c in database.VW_listar_categorias select c).ToList();
            return ListaCategorias;
        }

        public List<VW_listar_facilitadores> VW_listar_facilitadores()
        {
            var Listafacilitadores = (from c in database.VW_listar_facilitadores select c).ToList();
            return Listafacilitadores;
        }
    }
}
