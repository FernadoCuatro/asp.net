﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MillenniumCalendar.Controllers
{
    public class UsuariosController : Controller
    {

        // Contexto de datos
        MillenniumCalendarDataContext database = new MillenniumCalendarDataContext();

        // GET: Usuarios
        public ActionResult Index()
        {
            // Listar todos los administradores
            var ListaAdministradores = database.SP_mostrar_administradores().ToList();
            return View(ListaAdministradores);
        }

        // GET: Usuarios/Details/5
        public ActionResult Details(int id)
        {
            var info_administrador = database.SP_buscar_administrador_id(id);
            return View(info_administrador);
        }

        // GET: Usuarios/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Usuarios/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection, administrador administrador_datos, login login_datos)
        {
            try
            {
                administrador_datos.administrador_inserta = Session["nombre_completo"].ToString();
                administrador_datos.fecha_inserta = DateTime.Now;

                database.SP_ingresar_administrador(administrador_datos.nombre, administrador_datos.apellido, administrador_datos.estado_administrador, administrador_datos.administrador_inserta, administrador_datos.fecha_inserta);
                // Actualiza los datos en la tabla administrador
                database.SubmitChanges();

                // Obtenemos el ultimo id de administrador insertado para usarlo en el login
                int ultimo_administrador_id = database.administrador.OrderByDescending(x => x.id_administrador).First().id_administrador;

                database.SP_agregar_login(ultimo_administrador_id,login_datos.correo, login_datos.login_inserta, "c@l3nd4R-Ml^!", login_datos.estado_login, administrador_datos.administrador_inserta, administrador_datos.fecha_inserta);
                // Actualiza los datos en la tabla login
                database.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Usuarios/Edit/5
        public ActionResult Edit(int id)
        {
            var info_administrador = database.SP_buscar_administrador_id(id).Single();
            return View(info_administrador);
        }

        // POST: Usuarios/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection, administrador administrador_datos, login login_datos)
        {
            try
            {
                // TODO: Add update logic here
                administrador_datos.administrador_actualiza = Session["nombre_completo"].ToString();
                administrador_datos.fecha_actualiza = DateTime.Now;

                database.SP_actualizar_administrador(id, administrador_datos.nombre, administrador_datos.apellido, administrador_datos.estado_administrador, administrador_datos.administrador_actualiza, administrador_datos.fecha_actualiza);
                database.SP_actualiza_login(id, login_datos.correo, login_datos.estado_login, administrador_datos.administrador_actualiza, administrador_datos.fecha_actualiza);

                database.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return RedirectToAction("Index");
            }
        }

        // GET: Usuarios/Delete/5
        public ActionResult Delete(int id)
        {
            var info_administrador = database.SP_buscar_administrador_id(id).Single();
            return View(info_administrador);
        }

        // POST: Usuarios/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                database.SP_eliminar_administrador(id);
                database.SP_eliminar_login(id);
                database.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
