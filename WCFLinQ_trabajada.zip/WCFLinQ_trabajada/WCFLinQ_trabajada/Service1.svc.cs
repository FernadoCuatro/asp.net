﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

// Este es el servicio 
namespace WCFLinQ_trabajada
{
    public class Service1 : IService1
    {
        // Instanciamos la conexion
        // Con el contexto de datos
        databaseDataContext database = new databaseDataContext();

        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }
       
        // Aqui se declara lo que se hizo en la interfaz
        // El metodo de la interfaz debe declararse en el servicio
        public Usuario Login(Usuario Modelo)
        {
            // Hacemos el objeto de la clase
            Usuario user = new Usuario();

            try
            {
                // var usuario_encontrado = (from c in database.usuarios where = );
                // var usuario_encontrado = database.SP_ValidarUsuario(Modelo.usuario, Modelo.clave, "Pr09r@2");

                var usuario_encontrado = (from c in database.usuarios
                                          where c.Login == Modelo.usuario 
                                          select c).ToList();

                if (usuario_encontrado.Count > 0)
                {
                    // Aqui el usuario se encuentra
                    user.nombre_usuario = usuario_encontrado[0].Nombre;
                    user.usuario = usuario_encontrado[0].Login;
                    user.id_usuario = usuario_encontrado[0].idUsuario;
                }
                else
                {
                    user.id_usuario = 0;
                    user.mensaje_error = "Usuario no encontrado";
                }

            }
            catch (Exception ex)
            {
                user.id_usuario = 0;
                user.mensaje_error = ex.Message;
            }

            return user;
        }
    }
}
