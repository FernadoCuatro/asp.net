﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

// Esta es la interfaz
namespace WCFLinQ_trabajada
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IService1" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        string GetData(int value);

        // Clase dentro de la interfaz
        // Lo retorna y recibe los parametros
        // Ya esta en la interfaz, solo falta programar.

        // IMPORTANTE EL OPERATION CONTRACT, SI NO NO APARECE EN EL SERVICIO
        [OperationContract]
        Usuario Login(Usuario Modelo);
    }

    // Creamos una clase usuario

    // Tiene que tener el nombre 
    [DataContract]
    public class Usuario
    {
        // Propiedades
        // Todas tiene que llevar el DataMember
        [DataMember]
        public int id_usuario { get; set; }
        [DataMember]
        public string usuario { get; set; }
        [DataMember]
        public string clave { get; set; }
        [DataMember]
        public string nombre_usuario { get; set; }
        [DataMember]
        public string mensaje_error { get; set; }
    }

}
