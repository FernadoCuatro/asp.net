﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class frmLogin : System.Web.UI.Page
{
    //Referencia a la capa 2 intermedia
    ConexionSql cn = new ConexionSql();
    DataSet ds = new DataSet();

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnIngresar_Click(object sender, EventArgs e)
    {
        ds = cn.ValidarUsuario(txtLogin.Text, txtPassword.Text);
        if (ds != null)//Si se ejecutó correctamente
        {
            if (ds.Tables.Count > 0)//Si trae tablas de datos
            {
                if (ds.Tables["Usuario"].Rows.Count > 0)//Si trae registros
                {
                    if (ds.Tables["Usuario"].Rows[0]["IdUsuario"].ToString() != "-1")
                    {
                        lblMensajes.Text = "Acceso Concedido. Bienvenido: " + ds.Tables["Usuario"].Rows[0]["Nombre"].ToString();
                    }
                    else
                        lblMensajes.Text = "Acceso Denegado. Validar credenciales!";
                }
                else
                    lblMensajes.Text = "No hay registros que consultar!";
            }
            else
                lblMensajes.Text = "No hay tablas que consultar!";
        }
        else
            lblMensajes.Text = "Error en la ejecución del proceso!";
    }
}