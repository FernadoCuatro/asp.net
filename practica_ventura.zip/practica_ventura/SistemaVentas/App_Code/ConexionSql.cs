﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;//ADO.NET
using System.Data.SqlClient;//Cliente para Sql-Server

/// Capa de Acceso a Datos (Capa 2 Intermedia)
public class ConexionSql
{
    //Variables de clase
    DataSet ds = new DataSet();//Repositorio universal de datos
    SqlDataAdapter da;//Clase para ejecutar procesos en la base de datos (SP,FN, Vistas o Sentencias Sql directas)
    string strConex = @"Data Source=KIRVEN\SQLEXPRESS; Initial Catalog=Progra2_Ventas; User='UserProgra2'; Password='123'";
    string Patron = "Pr09r@2";

    //Constructor de la clase
    public ConexionSql()
    {

    }

    public DataSet ValidarUsuario(string Login, string Password)
    {
        try
        {
            da = new SqlDataAdapter("SP_ValidarUsuario", strConex);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@Login", Login);
            da.SelectCommand.Parameters.AddWithValue("@Password", Password);
            da.SelectCommand.Parameters.AddWithValue("@Patron", Patron);
            da.Fill(ds, "Usuario");
            return ds;
        }
        catch (Exception ex)
        {
            return null;
        }
    }
}