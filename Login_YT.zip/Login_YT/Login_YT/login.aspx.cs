﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace Login_YT
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnIngresar_Click(object sender, EventArgs e)
        {
            string patron = "login_Yt";

            // Variable para conectar
            string conn = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            SqlConnection sqlContectar = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("SP_ValidarUsaario", sqlContectar)
            {
                CommandType = CommandType.StoredProcedure
            };
            // Abrimos la conexion
            cmd.Connection.Open();

            // Agregamos los parametros
            cmd.Parameters.Add("@usuario", SqlDbType.VarChar, 50).Value = txtUsuario.Text;
            cmd.Parameters.Add("@clave", SqlDbType.VarChar, 50).Value = txtPassword.Text;
            cmd.Parameters.Add("@patron", SqlDbType.VarChar, 50).Value = patron;

            // Lector de datos ejecutado por el SqlCommand
            SqlDataReader dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                // Creamos una nueva sesion
                Session["userLogin"] = txtUsuario.Text;

                // Agregamos un sesion de usuario
                Response.Redirect("index.aspx");

                lblAlerta.Visible = false;
            }
            else
            {
                lblAlerta.Visible = true;
                lblAlerta.Text = "Los datos son incorrectos";
            }

            // Cerramos la conexion
            cmd.Connection.Close();
        }
    }
}