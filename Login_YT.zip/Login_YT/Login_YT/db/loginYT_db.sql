create database login_Yt;
use login_Yt;

-- Creamos una tabla
create table usuarios (
id_usuario int identity(1,1),
usuario varchar(50),
clave varbinary(50)
);

-- Creamos procedimientos almacenados
create procedure SP_AgregarUsuario
@usuario varchar(50),
@clave varchar(50),
@patron varchar(50)
as begin
insert into usuarios values(@usuario, ENCRYPTBYPASSPHRASE(@patron, @clave))
end

create procedure SP_ValidarUsaario
@usuario varchar(50),
@clave varchar(50),
@patron varchar(50)
as begin
select * from usuarios where usuario = @usuario and CONVERT(varchar(50), DECRYPTBYPASSPHRASE(@patron, clave)) = @clave
end

SP_AgregarUsuario 'Fernando', 'Hola123', 'login_Yt';
select * from usuarios;

SP_ValidarUsaario 'Fernando', 'Hola123', 'login_Yt';