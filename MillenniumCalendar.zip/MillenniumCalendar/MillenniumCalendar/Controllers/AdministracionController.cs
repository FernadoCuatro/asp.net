﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MillenniumCalendar.Controllers
{
    public class AdministracionController : Controller
    {

        // Contexto de datos
        MillenniumCalendarDataContext database = new MillenniumCalendarDataContext();

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Cerrar()
        {
            return RedirectToAction("Index", "Inicio");
        }

        public ActionResult Informacion()
        {
            // Listar todos los datos de la tabla administrador_actividad
            var ListaInformacion = database.SP_mostrar_administrador_actividad().ToList();
            return View(ListaInformacion);
        }
    }
}