﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MillenniumCalendar.Controllers
{
    public class CategoriasController : Controller
    {
        // Contexto de datos
        MillenniumCalendarDataContext database = new MillenniumCalendarDataContext();

        // GET: Categorias
        public ActionResult Index()
        {
            // Listar todos los facilitadores
            var ListaCategorias = database.SP_mostrar_categorias().ToList();

            return View(ListaCategorias);
        }

        // GET: Categorias/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Categorias/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection, categoria datos_categoria)
        {
            try
            {
                // TODO: Add insert logic here
                datos_categoria.usuario_inserta = Session["nombre_completo"].ToString();
                datos_categoria.fecha_inserta = DateTime.Now;

                database.SP_agregar_categoria(datos_categoria.nombre_categoria, datos_categoria.descripcion, datos_categoria.estado_categoria, datos_categoria.usuario_inserta, datos_categoria.fecha_inserta);
                database.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Categorias/Edit/5
        public ActionResult Edit(int id)
        {
            var info_categoria = database.SP_buscar_categoria_id(id).Single();
            return View(info_categoria);
        }

        // POST: Categorias/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection, categoria datos_categoria)
        {
            try
            {
                // TODO: Add update logic here
                datos_categoria.usuario_actualiza = Session["nombre_completo"].ToString();
                datos_categoria.fecha_actualiza = DateTime.Now;

                database.SP_actualiza_categoria(id, datos_categoria.nombre_categoria, datos_categoria.descripcion, datos_categoria.estado_categoria, datos_categoria.usuario_actualiza, datos_categoria.fecha_actualiza);
                database.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Categorias/Delete/5
        public ActionResult Delete(int id)
        {
            var info_categoria = database.SP_buscar_categoria_id(id).Single();
            return View(info_categoria);
        }

        // POST: Categorias/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                database.SP_eliminar_categoria(id);
                database.SubmitChanges();

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
